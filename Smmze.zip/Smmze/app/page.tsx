import { HeroSection } from "@/components/hero-section"
import { Features } from "@/components/features"
import { Testimonials } from "@/components/testimonials"

export default function Home() {
  return (
    <div className="flex flex-col">
      <HeroSection />
      <Features />
      <Testimonials />
    </div>
  )
}