"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { 
  Instagram, 
  Twitter, 
  Youtube, 
  Users, 
  Heart, 
  MessageCircle, 
  Play,
  TrendingUp,
  Clock,
  CheckCircle,
  Info,
  Calculator
} from "lucide-react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardNav } from "@/components/dashboard-nav"

const services = {
  instagram: [
    { name: "Takipçi", icon: Users, min: 100, max: 100000, price: 0.01, description: "Gerçek ve aktif Instagram takipçileri" },
    { name: "Beğeni", icon: Heart, min: 50, max: 50000, price: 0.005, description: "Yüksek kaliteli Instagram beğenileri" },
    { name: "Yorum", icon: MessageCircle, min: 10, max: 1000, price: 0.02, description: "Özelleştirilmiş Instagram yorumları" },
    { name: "İzlenme", icon: Play, min: 1000, max: 1000000, price: 0.001, description: "Instagram Reels ve video izlenme" },
  ],
  twitter: [
    { name: "Takipçi", icon: Users, min: 100, max: 50000, price: 0.008, description: "Kaliteli Twitter takipçileri" },
    { name: "Beğeni", icon: Heart, min: 50, max: 25000, price: 0.003, description: "Twitter beğeni hizmetleri" },
    { name: "Retweet", icon: TrendingUp, min: 25, max: 5000, price: 0.01, description: "Twitter retweet hizmetleri" },
    { name: "Yorum", icon: MessageCircle, min: 10, max: 500, price: 0.015, description: "Twitter yorum hizmetleri" },
  ],
  youtube: [
    { name: "Abone", icon: Users, min: 100, max: 100000, price: 0.05, description: "YouTube abone hizmetleri" },
    { name: "İzlenme", icon: Play, min: 1000, max: 5000000, price: 0.002, description: "YouTube video izlenme" },
    { name: "Beğeni", icon: Heart, min: 100, max: 100000, price: 0.01, description: "YouTube video beğeni" },
    { name: "Yorum", icon: MessageCircle, min: 10, max: 1000, price: 0.03, description: "YouTube yorum hizmetleri" },
  ]
}

const platforms = [
  { id: "instagram", name: "Instagram", icon: Instagram, color: "from-blue-500 to-cyan-600" },
  { id: "twitter", name: "Twitter", icon: Twitter, color: "from-sky-400 to-blue-600" },
  { id: "youtube", name: "YouTube", icon: Youtube, color: "from-red-500 to-red-700" },
]

export default function NewOrderPage() {
  const [selectedPlatform, setSelectedPlatform] = useState<string>("")
  const [selectedService, setSelectedService] = useState<any>(null)
  const [quantity, setQuantity] = useState<string>("")
  const [link, setLink] = useState<string>("")
  const [notes, setNotes] = useState<string>("")
  const [isCalculating, setIsCalculating] = useState(false)

  const calculatePrice = () => {
    if (!selectedService || !quantity) return 0
    const qty = parseInt(quantity)
    if (isNaN(qty)) return 0
    return qty * selectedService.price
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle order submission
    console.log("Order submitted:", {
      platform: selectedPlatform,
      service: selectedService,
      quantity,
      link,
      notes,
      total: calculatePrice()
    })
  }

  return (
    <div className="flex h-screen bg-background">
      <DashboardNav />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <DashboardHeader 
          title="Yeni Sipariş" 
          subtitle="Sosyal medya hizmeti sipariş edin"
        />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-6xl mx-auto">
            <form onSubmit={handleSubmit} className="grid lg:grid-cols-3 gap-8">
              {/* Left Column - Platform and Service Selection */}
              <div className="lg:col-span-2 space-y-6">
                {/* Platform Selection */}
                <Card>
                  <CardHeader>
                    <CardTitle>Platform Seçin</CardTitle>
                    <CardDescription>
                      Hizmet almak istediğiniz sosyal medya platformunu seçin
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {platforms.map((platform) => (
                        <button
                          key={platform.id}
                          type="button"
                          onClick={() => {
                            setSelectedPlatform(platform.id)
                            setSelectedService(null)
                            setQuantity("")
                          }}
                          className={`p-4 border rounded-lg text-center transition-all hover:shadow-md ${
                            selectedPlatform === platform.id
                              ? "border-primary bg-primary/5"
                              : "border-border hover:border-primary/50"
                          }`}
                        >
                          <div className={`w-12 h-12 mx-auto mb-2 rounded-full bg-gradient-to-r ${platform.color} flex items-center justify-center`}>
                            <platform.icon className="h-6 w-6 text-white" />
                          </div>
                          <span className="font-medium">{platform.name}</span>
                        </button>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Service Selection */}
                {selectedPlatform && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Hizmet Seçin</CardTitle>
                      <CardDescription>
                        {platforms.find(p => p.id === selectedPlatform)?.name} için hizmet seçin
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-2 gap-4">
                        {services[selectedPlatform as keyof typeof services].map((service, index) => (
                          <button
                            key={index}
                            type="button"
                            onClick={() => setSelectedService(service)}
                            className={`p-4 border rounded-lg text-left transition-all hover:shadow-md ${
                              selectedService === service
                                ? "border-primary bg-primary/5"
                                : "border-border hover:border-primary/50"
                            }`}
                          >
                            <div className="flex items-center gap-3 mb-2">
                              <div className="p-2 bg-primary/10 rounded-lg">
                                <service.icon className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <div className="font-medium">{service.name}</div>
                                <div className="text-sm text-muted-foreground">
                                  ₺{service.price} başına
                                </div>
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">
                              {service.description}
                            </p>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span>Min: {service.min.toLocaleString()}</span>
                              <span>Max: {service.max.toLocaleString()}</span>
                            </div>
                          </button>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Order Details */}
                {selectedService && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Sipariş Detayları</CardTitle>
                      <CardDescription>
                        Sipariş bilgilerinizi girin
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="link">Post Linki</Label>
                        <Input
                          id="link"
                          placeholder="https://instagram.com/p/..."
                          value={link}
                          onChange={(e) => setLink(e.target.value)}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="quantity">Miktar</Label>
                        <div className="flex items-center gap-4">
                          <Input
                            id="quantity"
                            type="number"
                            placeholder={`${selectedService.min} - ${selectedService.max}`}
                            value={quantity}
                            onChange={(e) => setQuantity(e.target.value)}
                            min={selectedService.min}
                            max={selectedService.max}
                            required
                          />
                          <Button type="button" variant="outline" size="sm">
                            <Calculator className="h-4 w-4 mr-2" />
                            Hesapla
                          </Button>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Minimum {selectedService.min.toLocaleString()}, maksimum {selectedService.max.toLocaleString()}
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="notes">Notlar (Opsiyonel)</Label>
                        <Textarea
                          id="notes"
                          placeholder="Siparişle ilgili özel notlarınız..."
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          rows={3}
                        />
                      </div>

                      <Alert>
                        <Info className="h-4 w-4" />
                        <AlertDescription>
                          Siparişiniz otomatik olarak işlenecektir. Teslimat süresi miktarına göre değişiklik gösterebilir.
                        </AlertDescription>
                      </Alert>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Right Column - Order Summary */}
              <div className="space-y-6">
                {/* Order Summary */}
                <Card className="sticky top-6">
                  <CardHeader>
                    <CardTitle>Sipariş Özeti</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {selectedPlatform ? (
                      <>
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-full bg-gradient-to-r ${platforms.find(p => p.id === selectedPlatform)?.color} flex items-center justify-center`}>
                            {React.createElement(platforms.find(p => p.id === selectedPlatform)!.icon, { className: "h-5 w-5 text-white" })}
                          </div>
                          <div>
                            <div className="font-medium">
                              {platforms.find(p => p.id === selectedPlatform)?.name}
                            </div>
                            {selectedService && (
                              <div className="text-sm text-muted-foreground">
                                {selectedService.name}
                              </div>
                            )}
                          </div>
                        </div>

                        <Separator />

                        {selectedService && (
                          <>
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span>Birim Fiyat:</span>
                                <span>₺{selectedService.price.toFixed(3)}</span>
                              </div>
                              <div className="flex justify-between text-sm">
                                <span>Miktar:</span>
                                <span>{quantity || "0"}</span>
                              </div>
                              <Separator />
                              <div className="flex justify-between font-medium">
                                <span>Toplam:</span>
                                <span className="text-lg">₺{calculatePrice().toFixed(2)}</span>
                              </div>
                            </div>

                            <div className="space-y-2">
                              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                <Clock className="h-4 w-4" />
                                <span>Tahmini teslimat: 1-24 saat</span>
                              </div>
                              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                <CheckCircle className="h-4 w-4" />
                                <span>Otomatik teslimat</span>
                              </div>
                            </div>
                          </>
                        )}

                        <Button 
                          type="submit" 
                          className="w-full" 
                          disabled={!selectedService || !quantity || !link}
                        >
                          Siparişi Tamamla
                        </Button>
                      </>
                    ) : (
                      <div className="text-center text-muted-foreground py-8">
                        <p>Lütfen bir platform seçin</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Balance Info */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Bakiye Bilgisi</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Mevcut Bakiye:</span>
                        <span className="font-medium">₺1,234.56</span>
                      </div>
                      {selectedService && quantity && (
                        <>
                          <div className="flex justify-between">
                            <span>Sipariş Tutarı:</span>
                            <span className="font-medium">₺{calculatePrice().toFixed(2)}</span>
                          </div>
                          <Separator />
                          <div className="flex justify-between font-medium">
                            <span>Kalan Bakiye:</span>
                            <span>₺{(1234.56 - calculatePrice()).toFixed(2)}</span>
                          </div>
                        </>
                      )}
                    </div>
                    <Button variant="outline" className="w-full mt-4">
                      Bakiye Yükle
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </form>
          </div>
        </main>
      </div>
    </div>
  )
}