import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SmmZe - Türkiye'nin En Güvenilir SMM Paneli",
  description: "SmmZe ile Instagram, Twitter, YouTube ve daha birçok platform için takipçi, beğeni ve izlenme hizmetleri. Hızlı, güvenilir ve uygun fiyatlı SMM çözümleri.",
  keywords: ["SMM panel", "Instagram takipçi", "Twitter takipçi", "YouTube izlenme", "sosyal medya hizmetleri", "SmmZe"],
  authors: [{ name: "SmmZe Team" }],
  openGraph: {
    title: "SmmZe - Sosyal Medya Hizmetleri",
    description: "Türkiye'nin en güvenilir SMM paneli ile sosyal medya hesaplarınızı büyütün",
    url: "https://smmze.com",
    siteName: "SmmZe",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "SmmZe - Sosyal Medya Hizmetleri",
    description: "Türkiye'nin en güvenilir SMM paneli",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="tr" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          <div className="min-h-screen flex flex-col">
            <Header />
            <main className="flex-1">
              {children}
            </main>
            <Footer />
          </div>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
