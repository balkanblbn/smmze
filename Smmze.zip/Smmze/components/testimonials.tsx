"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Ahmet Yılmaz",
    role: "İçerik Üreticisi",
    avatar: "👨‍💼",
    content: "SmmZe sayesinde Instagram hesabım 10k takipçiye ulaştı! Hizmet gerçekten çok hızlı ve kaliteli. Kesinlikle tavsiye ederim.",
    rating: 5,
    date: "2 gün önce"
  },
  {
    name: "Ayşe Demir",
    role: "E-ticaret Sahibi",
    avatar: "👩‍💼",
    content: "Müşterilerim için sosyal medya hizmetleri alıyorum. SmmZe'nin otomatik sistemi sayesinde işlerim çok kolaylaştı.",
    rating: 5,
    date: "1 hafta önce"
  },
  {
    name: "Mehmet Kaya",
    role: "Digital Marketing Uzmanı",
    avatar: "👨‍💻",
    content: "Fiyatlar çok uygun ve hizmet kalitesi harika. 6 aydır kullanıyorum ve hiç sorun yaşamadım. En iyi SMM paneli!",
    rating: 5,
    date: "2 hafta önce"
  },
  {
    name: "Zeynep Arslan",
    role: "Tasarımcı",
    avatar: "👩‍🎨",
    content: "Portfolyom için beğeni ve takipçi hizmeti aldım. Gerçek ve organik kullanıcılar geldi. Çok memnun kaldım.",
    rating: 5,
    date: "3 hafta önce"
  }
]

export function Testimonials() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Müşterilerimiz Ne Diyor?
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Binlerce mutlu müşterimizden bazılarının yorumları
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="h-full">
              <CardContent className="p-6">
                {/* Rating */}
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < testimonial.rating
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-muted-foreground"
                      }`}
                    />
                  ))}
                </div>
                
                {/* Content */}
                <p className="text-muted-foreground mb-4 text-sm leading-relaxed">
                  "{testimonial.content}"
                </p>
                
                {/* Author */}
                <div className="flex items-center gap-3">
                  <div className="text-2xl">{testimonial.avatar}</div>
                  <div>
                    <div className="font-semibold text-sm">{testimonial.name}</div>
                    <div className="text-xs text-muted-foreground">{testimonial.role}</div>
                    <div className="text-xs text-muted-foreground">{testimonial.date}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="text-center">
            <div className="text-3xl lg:text-4xl font-bold text-primary mb-2">
              50K+
            </div>
            <div className="text-muted-foreground">Mutlu Müşteri</div>
          </div>
          <div className="text-center">
            <div className="text-3xl lg:text-4xl font-bold text-primary mb-2">
              1M+
            </div>
            <div className="text-muted-foreground">Teslim Edilen Sipariş</div>
          </div>
          <div className="text-center">
            <div className="text-3xl lg:text-4xl font-bold text-primary mb-2">
              24/7
            </div>
            <div className="text-muted-foreground">Destek Hizmeti</div>
          </div>
          <div className="text-center">
            <div className="text-3xl lg:text-4xl font-bold text-primary mb-2">
              99.9%
            </div>
            <div className="text-muted-foreground">Memnuniyet Oranı</div>
          </div>
        </div>
      </div>
    </section>
  )
}