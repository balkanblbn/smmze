"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { 
  LayoutDashboard, 
  PlusCircle, 
  History, 
  Wallet, 
  Users, 
  Settings, 
  HelpCircle,
  LogOut,
  Bell,
  User
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const navigation = [
  { name: "Panel", href: "/dashboard", icon: LayoutDashboard },
  { name: "Yeni Sipariş", href: "/dashboard/yeni-siparis", icon: PlusCircle },
  { name: "Sipariş Geçmişi", href: "/dashboard/siparisler", icon: History },
  { name: "Bakiye İşlemleri", href: "/dashboard/bakiye", icon: Wallet },
  { name: "Alt Kullanıcılar", href: "/dashboard/kullanicilar", icon: Users },
  { name: "Ayarlar", href: "/dashboard/ayarlar", icon: Settings },
]

const userActions = [
  { name: "Profil", href: "/dashboard/profil", icon: User },
  { name: "Bildirimler", href: "/dashboard/bildirimler", icon: Bell },
  { name: "Yardım", href: "/dashboard/yardim", icon: HelpCircle },
]

export function DashboardNav() {
  const pathname = usePathname()

  return (
    <nav className="flex flex-col w-64 bg-card border-r min-h-screen p-4">
      {/* Logo */}
      <div className="flex items-center space-x-2 mb-8 px-2">
        <span className="font-bold text-xl bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
          SmmZe
        </span>
      </div>

      {/* Navigation */}
      <div className="space-y-2 flex-1">
        {navigation.map((item) => {
          const isActive = pathname === item.href
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              )}
            >
              <item.icon className="h-5 w-5" />
              <span>{item.name}</span>
            </Link>
          )
        })}
      </div>

      {/* User Actions */}
      <div className="space-y-2 pt-4 border-t">
        {userActions.map((item) => (
          <Link
            key={item.name}
            href={item.href}
            className="flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
          >
            <item.icon className="h-5 w-5" />
            <span>{item.name}</span>
          </Link>
        ))}
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="w-full justify-start px-3 py-2 h-auto">
              <div className="flex items-center space-x-3 w-full">
                <Avatar className="h-6 w-6">
                  <AvatarImage src="/placeholder-avatar.jpg" />
                  <AvatarFallback>AY</AvatarFallback>
                </Avatar>
                <div className="flex-1 text-left">
                  <div className="text-sm font-medium">Ahmet Yılmaz</div>
                  <div className="text-xs text-muted-foreground">Profil</div>
                </div>
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Hesabım</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href="/dashboard/profil">
                <User className="mr-2 h-4 w-4" />
                Profil Ayarları
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/dashboard/bildirimler">
                <Bell className="mr-2 h-4 w-4" />
                Bildirimler
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/dashboard/yardim">
                <HelpCircle className="mr-2 h-4 w-4" />
                Yardım ve Destek
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-red-600">
              <LogOut className="mr-2 h-4 w-4" />
              Çıkış Yap
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </nav>
  )
}