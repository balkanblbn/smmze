"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Instagram, Twitter, Youtube, Star, Zap, Shield, Users } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative py-20 lg:py-32 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-cyan-600/20 to-sky-600/20"></div>
      <div className="absolute inset-0 opacity-20">
        <div className="h-full w-full" style={{
          backgroundImage: `radial-gradient(circle at 25% 25%, rgba(59, 130, 246, 0.1) 0%, transparent 50%), radial-gradient(circle at 75% 75%, rgba(6, 182, 212, 0.1) 0%, transparent 50%)`
        }}></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Zap className="h-4 w-4" />
              <span>Türkiye'nin #1 SMM Paneli</span>
            </div>
            
            <h1 className="text-4xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-400 via-cyan-400 to-sky-400 bg-clip-text text-transparent">
              Sosyal Medya Hesaplarınızı
              <br />
              <span className="text-white">Anında Büyütün</span>
            </h1>
            
            <p className="text-xl text-muted-foreground mb-8 max-w-lg">
              Instagram, Twitter, YouTube ve daha birçok platform için takipçi, beğeni, 
              izlenme ve yorum hizmetleri. 7/24 otomatik teslimat!
            </p>
            
            {/* Features */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-green-500/20 rounded-lg">
                  <Shield className="h-5 w-5 text-green-500" />
                </div>
                <div>
                  <div className="font-semibold">Güvenli</div>
                  <div className="text-sm text-muted-foreground">%100 Güvenlik</div>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="p-2 bg-cyan-500/20 rounded-lg">
                  <Zap className="h-5 w-5 text-cyan-500" />
                </div>
                <div>
                  <div className="font-semibold">Hızlı</div>
                  <div className="text-sm text-muted-foreground">Anında Teslimat</div>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-500/20 rounded-lg">
                  <Users className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <div className="font-semibold">Kaliteli</div>
                  <div className="text-sm text-muted-foreground">Gerçek Kullanıcılar</div>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700" asChild>
                <Link href="/kayit">Hemen Başla</Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/hizmetler">Hizmetleri İncele</Link>
              </Button>
            </div>
          </div>
          
          {/* Right Content - Quick Login */}
          <div className="flex justify-center lg:justify-end">
            <Card className="w-full max-w-md backdrop-blur-sm bg-card/80 border-border/50">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">Hızlı Giriş</CardTitle>
                <CardDescription>
                  Hesabınıza hızlıca giriş yapın
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <form className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">E-posta</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="ornek@email.com"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Şifre</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      required
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" className="rounded" />
                      <span className="text-sm">Beni hatırla</span>
                    </label>
                    <Link href="/sifremi-unuttum" className="text-sm text-primary hover:underline">
                      Şifremi unuttum?
                    </Link>
                  </div>
                  <Button type="submit" className="w-full">
                    Giriş Yap
                  </Button>
                </form>
                
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background px-2 text-muted-foreground">
                      Veya
                    </span>
                  </div>
                </div>
                
                <div className="text-center">
                  <span className="text-sm text-muted-foreground">
                    Hesabınız yok mu?{" "}
                    <Link href="/kayit" className="text-primary hover:underline font-medium">
                      Kayıt Olun
                    </Link>
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        
        {/* Social Media Icons */}
        <div className="mt-16 flex justify-center gap-8">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Instagram className="h-6 w-6" />
            <span>Instagram</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Twitter className="h-6 w-6" />
            <span>Twitter</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Youtube className="h-6 w-6" />
            <span>YouTube</span>
          </div>
        </div>
      </div>
    </section>
  )
}