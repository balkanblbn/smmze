import Link from "next/link"
import { Instagram, Twitter, Facebook, Mail, Phone, MapPin } from "lucide-react"

export function Footer() {
  const footerLinks = {
    Hizmetler: [
      { name: "Instagram Takipçi", href: "/hizmetler/instagram-takipci" },
      { name: "Instagram Beğeni", href: "/hizmetler/instagram-begeni" },
      { name: "Twitter Takipçi", href: "/hizmetler/twitter-takipci" },
      { name: "YouTube İzlenme", href: "/hizmetler/youtube-izlenme" },
    ],
    Şirket: [
      { name: "Hakkımızda", href: "/hakkimizda" },
      { name: "İletişim", href: "/iletisim" },
      { name: "Gizlilik Politikası", href: "/gizlilik" },
      { name: "Kullanım Şartları", href: "/sartlar" },
    ],
    Destek: [
      { name: "SSS", href: "/sss" },
      { name: "Müşteri Hizmetleri", href: "/destek" },
      { name: "Ödeme Seçenekleri", href: "/odeme" },
      { name: "Geri Ödeme Politikası", href: "/iade" },
    ],
  }

  const socialLinks = [
    { name: "Instagram", href: "#", icon: Instagram },
    { name: "Twitter", href: "#", icon: Twitter },
    { name: "Facebook", href: "#", icon: Facebook },
  ]

  return (
    <footer className="bg-muted/50 border-t">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <span className="font-bold text-2xl bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                SmmZe
              </span>
            </div>
            <p className="text-muted-foreground mb-6 max-w-md">
              Türkiye'nin en güvenilir SMM paneli. Sosyal medya hesaplarınızı büyütmek için 
              en kaliteli ve en hızlı hizmetler burada!
            </p>
            
            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center space-x-3 text-muted-foreground">
                <Mail className="h-5 w-5" />
                <span>info@smmze.com</span>
              </div>
              <div className="flex items-center space-x-3 text-muted-foreground">
                <Phone className="h-5 w-5" />
                <span>+90 555 123 45 67</span>
              </div>
              <div className="flex items-center space-x-3 text-muted-foreground">
                <MapPin className="h-5 w-5" />
                <span>İstanbul, Türkiye</span>
              </div>
            </div>
          </div>

          {/* Footer Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="font-semibold mb-4">{category}</h3>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Section */}
        <div className="border-t mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-muted-foreground mb-4 md:mb-0">
              © 2024 SmmZe. Tüm hakları saklıdır.
            </div>
            
            {/* Social Links */}
            <div className="flex space-x-4">
              {socialLinks.map((social) => (
                <Link
                  key={social.name}
                  href={social.href}
                  className="text-muted-foreground hover:text-primary transition-colors"
                  aria-label={social.name}
                >
                  <social.icon className="h-5 w-5" />
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}