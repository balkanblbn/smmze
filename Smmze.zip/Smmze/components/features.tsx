"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Instagram, Twitter, Youtube, MessageCircle, Heart, Play, Users, TrendingUp, Clock, Shield } from "lucide-react"
import Link from "next/link"

const services = [
  {
    platform: "Instagram",
    icon: Instagram,
    color: "from-blue-500 to-cyan-600",
    services: [
      { name: "Takipçi", icon: Users, price: "0.01 TL" },
      { name: "Beğeni", icon: Heart, price: "0.005 TL" },
      { name: "Yorum", icon: MessageCircle, price: "0.02 TL" },
      { name: "İzlenme", icon: Play, price: "0.001 TL" },
    ]
  },
  {
    platform: "Twitter",
    icon: Twitter,
    color: "from-sky-400 to-blue-600",
    services: [
      { name: "Takipçi", icon: Users, price: "0.008 TL" },
      { name: "Beğeni", icon: Heart, price: "0.003 TL" },
      { name: "Retweet", icon: TrendingUp, price: "0.01 TL" },
      { name: "Yorum", icon: MessageCircle, price: "0.015 TL" },
    ]
  },
  {
    platform: "YouTube",
    icon: Youtube,
    color: "from-red-500 to-red-700",
    services: [
      { name: "Abone", icon: Users, price: "0.05 TL" },
      { name: "İzlenme", icon: Play, price: "0.002 TL" },
      { name: "Beğeni", icon: Heart, price: "0.01 TL" },
      { name: "Yorum", icon: MessageCircle, price: "0.03 TL" },
    ]
  }
]

const features = [
  {
    icon: Clock,
    title: "Anında Teslimat",
    description: "Siparişleriniz otomatik olarak hemen işlenmeye başlanır"
  },
  {
    icon: Shield,
    title: "Güvenli Ödeme",
    description: "256-bit SSL şifreleme ile güvenli ödeme"
  },
  {
    icon: TrendingUp,
    title: "Kaliteli Hizmet",
    description: "Gerçek ve organik görünümlü hizmetler"
  },
  {
    icon: Users,
    title: "7/24 Destek",
    description: "Canlı destek ekibimiz her zaman yanınızda"
  }
]

export function Features() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Popüler Hizmetlerimiz
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            En çok tercih edilen sosyal medya hizmetleri
          </p>
        </div>
        
        {/* Services Grid */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <Card key={index} className="h-full">
              <CardHeader className="text-center pb-4">
                <div className={`w-16 h-16 mx-auto rounded-full bg-gradient-to-r ${service.color} flex items-center justify-center mb-4`}>
                  <service.icon className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-xl">{service.platform}</CardTitle>
                <CardDescription>
                  En uygun fiyatlarla {service.platform} hizmetleri
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {service.services.map((item, itemIndex) => (
                  <div key={itemIndex} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-3">
                      <div className="p-1.5 bg-primary/10 rounded">
                        <item.icon className="h-4 w-4 text-primary" />
                      </div>
                      <span className="font-medium">{item.name}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {item.price}
                    </span>
                  </div>
                ))}
                <Button className="w-full mt-4" asChild>
                  <Link href="/hizmetler">Tümünü Gör</Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* Features */}
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Neden SmmZe?
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Sizi diğerlerinden ayıran özellikler
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="text-center">
              <CardContent className="p-6">
                <div className="w-12 h-12 mx-auto mb-4 bg-primary/10 rounded-lg flex items-center justify-center">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}