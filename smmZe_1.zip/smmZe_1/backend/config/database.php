<?php
class Database {
    private $host = 'localhost';
    private $db_name = 'smm_panel';
    // Güvenlik için .env dosyası veya ortam değişkeni kullanılması önerilir
    private $username = 'root';
    private $password = '';
    private $conn;

    public function connect() {
        $this->conn = null;
        try {
            $dsn = "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4";
            $this->conn = new PDO($dsn, $this->username, $this->password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_PERSISTENT => false, // Kalıcı bağlantı kapalı
            ]);
        } catch(PDOException $e) {
            // Hata mesajını logla, kullanıcıya detay gösterme
            error_log('DB Error: ' . $e->getMessage());
            throw new Exception("Veritabanı bağlantı hatası.");
        }
        return $this->conn;
    }
}
?>