<?php
header('Content-Type: application/json; charset=utf-8');

try {
    // Database bağlantı ayarları
    $host = 'localhost';
    $db_name = 'smm_panel';
    $username = 'root';
    $password = '';
    
    // 1. Veritabanı oluştur
    echo json_encode(['step' => 1, 'message' => 'Creating database...']);
    
    $pdo = new PDO("mysql:host=$host", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `$db_name`");
    
    // 2. Tabloları oluştur
    echo json_encode(['step' => 2, 'message' => 'Creating tables...']);
    
    $sql = "
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        balance DECIMAL(10, 2) DEFAULT 0.00,
        api_key VARCHAR(64) UNIQUE,
        status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );
    
    CREATE TABLE IF NOT EXISTS services (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        category VARCHAR(50) NOT NULL,
        price DECIMAL(10, 4) NOT NULL,
        min_quantity INT DEFAULT 100,
        max_quantity INT DEFAULT 10000,
        description TEXT,
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    
    CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        service_id INT NOT NULL,
        quantity INT NOT NULL,
        link VARCHAR(500) NOT NULL,
        charge DECIMAL(10, 4) NOT NULL,
        status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
        start_count INT DEFAULT 0,
        remains INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (service_id) REFERENCES services(id)
    );
    
    -- Test kullanıcısı (password: password123)
    INSERT IGNORE INTO users (username, email, password, balance, status) VALUES 
    ('admin', 'admin@smmpanel.com', '\$2y\$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1000.00, 'active');
    ";
    
    // Çoklu sorguları güvenli şekilde çalıştırmak için explode ile ayırıp sırayla çalıştır
    foreach (explode(';', $sql) as $query) {
        $query = trim($query);
        if ($query) {
            $pdo->exec($query);
        }
    }
    
    echo json_encode(['success' => true, 'message' => 'Installation completed successfully!']);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Installation failed: ' . $e->getMessage()]);
}
?>