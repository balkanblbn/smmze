document.addEventListener('DOMContentLoaded', function() {
    // Theme toggle functionality
    const themeToggle = document.getElementById('themeToggle');
    const htmlElement = document.documentElement;
    
    // Check for saved theme or prefer-color-scheme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        htmlElement.setAttribute('data-theme', savedTheme);
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        htmlElement.setAttribute('data-theme', 'dark');
    }
    
    // Theme toggle button event
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            const currentTheme = htmlElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            htmlElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
        });
    }
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show confirmation
            if (confirm('Çıkış yapmak istediğinize emin misiniz?')) {
                // API logout call
                fetch('../../backend/api/auth.php?action=logout', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Clear user data from localStorage
                        localStorage.removeItem('user');
                        // Redirect to login page
                        window.location.href = 'login.html';
                    } else {
                        alert('Çıkış yapılırken bir hata oluştu.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    window.location.href = 'login.html'; // Fallback
                });
            }
        });
    }
    
    // Category and service selection
    const categorySelect = document.getElementById('category');
    const serviceSelect = document.getElementById('service');
    
    if (categorySelect && serviceSelect) {
        categorySelect.addEventListener('change', function() {
            const category = this.value;
            // innerHTML yerine güvenli şekilde option ekle
            while (serviceSelect.firstChild) serviceSelect.removeChild(serviceSelect.firstChild);
            const defaultOption = document.createElement('option');
            defaultOption.value = '';
            defaultOption.textContent = 'Servis seçiniz...';
            serviceSelect.appendChild(defaultOption);
            
            if (category) {
                // Mock services based on category
                const services = {
                    'instagram': [
                        { id: 1, name: 'Instagram Takipçi (Hızlı)', price: '0.50' },
                        { id: 2, name: 'Instagram Beğeni (Orijinal)', price: '0.30' },
                        { id: 3, name: 'Instagram Yorum', price: '1.20' },
                        { id: 4, name: 'Instagram Story Görüntüleme', price: '0.10' }
                    ],
                    'youtube': [
                        { id: 5, name: 'YouTube Görüntüleme', price: '1.00' },
                        { id: 6, name: 'YouTube Beğeni', price: '0.80' },
                        { id: 7, name: 'YouTube Abone', price: '2.50' }
                    ],
                    'tiktok': [
                        { id: 8, name: 'TikTok Takipçi', price: '0.70' },
                        { id: 9, name: 'TikTok Beğeni', price: '0.40' },
                        { id: 10, name: 'TikTok Görüntüleme', price: '0.20' }
                    ],
                    'twitter': [
                        { id: 11, name: 'Twitter Takipçi', price: '0.60' },
                        { id: 12, name: 'Twitter Retweet', price: '0.90' },
                        { id: 13, name: 'Twitter Beğeni', price: '0.50' }
                    ],
                    'facebook': [
                        { id: 14, name: 'Facebook Beğeni', price: '0.70' },
                        { id: 15, name: 'Facebook Takipçi', price: '1.00' },
                        { id: 16, name: 'Facebook Yorum', price: '1.50' }
                    ]
                };
                
                if (services[category]) {
                    services[category].forEach(service => {
                        const option = document.createElement('option');
                        option.value = service.id;
                        option.textContent = `${service.name} - ₺${service.price}/1000`;
                        option.dataset.price = service.price;
                        serviceSelect.appendChild(option);
                    });
                }
            }
        });
    }
    
    // Quantity and charge calculation
    const quantityInput = document.getElementById('quantity');
    const chargeInput = document.getElementById('charge');
    
    if (quantityInput && serviceSelect && chargeInput) {
        // Function to calculate charge
        function calculateCharge() {
            const quantity = parseInt(quantityInput.value) || 0;
            const selectedOption = serviceSelect.options[serviceSelect.selectedIndex];
            
            if (selectedOption && selectedOption.dataset.price) {
                const pricePer1000 = parseFloat(selectedOption.dataset.price);
                const charge = (quantity * pricePer1000) / 1000;
                chargeInput.value = `₺${charge.toFixed(2)}`;
            } else {
                chargeInput.value = '₺0.00';
            }
        }
        
        // Event listeners
        quantityInput.addEventListener('input', calculateCharge);
        serviceSelect.addEventListener('change', calculateCharge);
    }
    
    // Order form submission
    const orderForm = document.getElementById('orderForm');
    if (orderForm) {
        orderForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const category = document.getElementById('category').value;
            const service = document.getElementById('service').value;
            const link = document.getElementById('link').value;
            const quantity = document.getElementById('quantity').value;
            
            // Validation
            if (!category || !service || !link || !quantity) {
                alert('Lütfen tüm alanları doldurun.');
                return;
            }
            
            // Validate URL
            try {
                new URL(link);
            } catch (e) {
                alert('Lütfen geçerli bir bağlantı girin.');
                return;
            }
            
            // Validate quantity
            const quantityNum = parseInt(quantity);
            if (quantityNum < 100 || quantityNum > 100000) {
                alert('Miktar 100 ile 100,000 arasında olmalıdır.');
                return;
            }
            
            // Show loading state
            const submitBtn = orderForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.textContent = 'Sipariş Gönderiliyor...';
            submitBtn.disabled = true;
            
            // Simulate API call (in real implementation, you would send to your backend)
            setTimeout(() => {
                alert('Sipariş başarıyla oluşturuldu!');
                orderForm.reset();
                document.getElementById('charge').value = '₺0.00';
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
                
                // Update stats (in real implementation, this would come from API)
                updateStats();
            }, 1500);
        });
    }
    
    // Update stats (mock function)
    function updateStats() {
        // In a real application, you would fetch updated stats from API
        console.log('Stats updated');
    }
    
    // Load user data
    function loadUserData() {
        // In a real application, you would fetch user data from API or localStorage
        // localStorage'da hassas veri tutma, sadece gerekli minimum bilgiyi al
        let user = { username: 'admin', balance: '1,250.00' };
        try {
            const stored = localStorage.getItem('user');
            if (stored) {
                const parsed = JSON.parse(stored);
                if (parsed && typeof parsed.username === 'string' && typeof parsed.balance !== 'undefined') {
                    user = { username: parsed.username, balance: parsed.balance };
                }
            }
        } catch (e) {}
        if (document.getElementById('username')) {
            document.getElementById('username').textContent = user.username;
        }
        if (document.getElementById('balance')) {
            document.getElementById('balance').textContent = `₺${user.balance}`;
        }
    }
    
    // Initialize
    loadUserData();
});