document.addEventListener('DOMContentLoaded', function() {
    // Theme toggle functionality
    const themeToggle = document.getElementById('theme-toggle');
    const htmlElement = document.documentElement;
    
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        htmlElement.setAttribute('data-theme', savedTheme);
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        htmlElement.setAttribute('data-theme', 'dark');
    }
    
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            if (htmlElement.getAttribute('data-theme') === 'dark') {
                htmlElement.setAttribute('data-theme', 'light');
                localStorage.setItem('theme', 'light');
            } else {
                htmlElement.setAttribute('data-theme', 'dark');
                localStorage.setItem('theme', 'dark');
            }
        });
    }
    
    // Login form functionality
    const loginForm = document.getElementById('loginForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            
            // Form validation
            if (!username || !password) {
                alert('Lütfen tüm alanları doldurun');
                return;
            }
            
            // Disable submit button
            const submitBtn = loginForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Giriş yapılıyor...';
            submitBtn.disabled = true;
            
            // Send login request
            fetch('../../backend/api/auth.php?action=login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    username: username,
                    password: password
                })
            })
            .then(response => {
                // Response'un JSON olup olmadığını kontrol et
                const contentType = response.headers.get('content-type');
                if (!contentType || !contentType.includes('application/json')) {
                    return response.text().then(text => {
                        throw new Error('Sunucu JSON döndürmedi: ' + text);
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    // Login successful - Store user data in localStorage
                    if (data.user) {
                        // Sadece gerekli minimum bilgiyi sakla
                        localStorage.setItem('user', JSON.stringify({ username: data.user.username, balance: data.user.balance }));
                    }
                    
                    // Redirect to dashboard
                    alert('Giriş başarılı! Dashboard\'a yönlendiriliyorsunuz...');
                    setTimeout(() => {
                        window.location.href = 'dashboard.html';
                    }, 1500);
                } else {
                    // Login failed
                    alert(data.message || 'Giriş başarısız. Lütfen bilgilerinizi kontrol edin.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Bir hata oluştu: ' + error.message);
            })
            .finally(() => {
                // Re-enable submit button
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            });
        });
    }
    
    // Check if user is already logged in
    function checkLoggedInUser() {
        const user = localStorage.getItem('user');
        if (user && window.location.pathname.includes('login.html')) {
            // User is already logged in, redirect to dashboard
            window.location.href = 'dashboard.html';
        }
    }
    
    // Run check on page load
    checkLoggedInUser();
});