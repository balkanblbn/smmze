// js/register.js
document.addEventListener('DOMContentLoaded', function() {
    // Theme toggle functionality
    const themeToggle = document.getElementById('theme-toggle');
    const htmlElement = document.documentElement;
    
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        htmlElement.setAttribute('data-theme', savedTheme);
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        htmlElement.setAttribute('data-theme', 'dark');
    }
    
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            if (htmlElement.getAttribute('data-theme') === 'dark') {
                htmlElement.setAttribute('data-theme', 'light');
                localStorage.setItem('theme', 'light');
            } else {
                htmlElement.setAttribute('data-theme', 'dark');
                localStorage.setItem('theme', 'dark');
            }
        });
    }
    
    // Register form functionality
    const registerForm = document.getElementById('registerForm');
    
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            // Form validation
            if (!username || !email || !password || !confirmPassword) {
                alert('Lütfen tüm alanları doldurun');
                return;
            }
            
            if (password.length < 6) {
                alert('Şifre en az 6 karakter olmalıdır');
                return;
            }
            
            if (password !== confirmPassword) {
                alert('Şifreler eşleşmiyor');
                return;
            }
            
            // Check terms agreement
            if (!document.getElementById('terms').checked) {
                alert('Kullanım şartlarını ve gizlilik politikasını kabul etmelisiniz');
                return;
            }
            
            // Disable submit button
            const submitBtn = registerForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Kayıt olunuyor...';
            submitBtn.disabled = true;
            
            // Send registration request
            console.log('API isteği gönderiliyor...'); // Debug
            fetch('../../backend/api/auth.php?action=register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    username: username,
                    email: email,
                    password: password
                })
            })
            .then(response => {
                console.log('Response alındı:', response); // Debug
                console.log('Response status:', response.status); // Debug
                console.log('Response headers:', [...response.headers.entries()]); // Debug
                
                // Response'un JSON olup olmadığını kontrol et
                const contentType = response.headers.get('content-type');
                console.log('Content-Type:', contentType); // Debug
                
                if (!contentType || !contentType.includes('application/json')) {
                    return response.text().then(text => {
                        console.error('Sunucu JSON döndürmedi, aldığımız içerik:', text);
                        throw new Error('Sunucu JSON döndürmedi. Aldığımız içerik: ' + text.substring(0, 200));
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    // Registration successful
                    alert('Kayıt başarılı! Giriş sayfasına yönlendiriliyorsunuz...');
                    setTimeout(() => {
                        window.location.href = 'login.html';
                    }, 2000);
                } else {
                    // Registration failed
                    alert(data.message || 'Kayıt başarısız. Lütfen tekrar deneyin.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Bir hata oluştu: ' + error.message);
            })
            .finally(() => {
                // Re-enable submit button
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            });
        });
    }
});