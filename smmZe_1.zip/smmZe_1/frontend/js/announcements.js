document.addEventListener('DOMContentLoaded', function() {
    // Theme toggle functionality
    const themeToggle = document.getElementById('themeToggle');
    const htmlElement = document.documentElement;
    
    // Check for saved theme or prefer-color-scheme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        htmlElement.setAttribute('data-theme', savedTheme);
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        htmlElement.setAttribute('data-theme', 'dark');
    }
    
    // Theme toggle button event
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            const currentTheme = htmlElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            htmlElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
        });
    }
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show confirmation
            if (confirm('Çıkış yapmak istediğinize emin misiniz?')) {
                // API logout call
                fetch('../../backend/api/auth.php?action=logout', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Clear user data from localStorage
                        localStorage.removeItem('user');
                        // Redirect to login page
                        window.location.href = 'login.html';
                    } else {
                        alert('Çıkış yapılırken bir hata oluştu.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    window.location.href = 'login.html'; // Fallback
                });
            }
        });
    }
    
    // Email subscription
    const subscriptionForm = document.querySelector('.subscription-form');
    const emailInput = document.getElementById('email-subscription');
    
    if (subscriptionForm && emailInput) {
        subscriptionForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = emailInput.value.trim();
            
            // Basic email validation
            if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                alert('Lütfen geçerli bir e-posta adresi girin.');
                return;
            }
            
            // Show loading state
            const submitBtn = subscriptionForm.querySelector('button');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = 'İşleniyor...';
            submitBtn.disabled = true;
            
            // Simulate API call (in real implementation, you would send to your backend)
            setTimeout(() => {
                alert('E-posta bildirimlerine başarıyla abone oldunuz!');
                emailInput.value = '';
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 1000);
        });
    }
    
    // Load user data
    function loadUserData() {
        // In a real application, you would fetch user data from API or localStorage
        const user = JSON.parse(localStorage.getItem('user')) || { username: 'admin', balance: '1,250.00' };
        if (document.getElementById('username')) {
            document.getElementById('username').textContent = user.username;
        }
        if (document.getElementById('balance')) {
            document.getElementById('balance').textContent = `₺${user.balance}`;
        }
    }
    
    // Initialize
    loadUserData();
});