document.addEventListener('DOMContentLoaded', function() {
    // Theme toggle functionality
    const themeToggle = document.getElementById('themeToggle');
    const htmlElement = document.documentElement;
    
    // Check for saved theme or prefer-color-scheme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        htmlElement.setAttribute('data-theme', savedTheme);
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        htmlElement.setAttribute('data-theme', 'dark');
    }
    
    // Theme toggle button event
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            const currentTheme = htmlElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            htmlElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
        });
    }
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show confirmation
            if (confirm('Çıkış yapmak istediğinize emin misiniz?')) {
                // API logout call
                fetch('../../backend/api/auth.php?action=logout', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Clear user data from localStorage
                        localStorage.removeItem('user');
                        // Redirect to login page
                        window.location.href = 'login.html';
                    } else {
                        alert('Çıkış yapılırken bir hata oluştu.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    window.location.href = 'login.html'; // Fallback
                });
            }
        });
    }
    
    // Filter functionality
    const filterButtons = document.querySelectorAll('.filter-btn, #status-filter, #service-filter, #date-filter');
    filterButtons.forEach(button => {
        button.addEventListener('change', function() {
            // In a real application, you would filter the orders
            console.log('Filter applied:', this.value);
            // Simulate filtering
            filterOrders();
        });
    });
    
    // Refresh button
    const refreshBtn = document.querySelector('.table-actions .btn-outline');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            // Show loading state
            const originalText = this.innerHTML;
            this.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="spin"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path><path d="M3 3v5h5"></path><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"></path><path d="M16 16h5v5"></path></svg> Yenileniyor...';
            
            // Simulate refresh
            setTimeout(() => {
                this.innerHTML = originalText;
                alert('Sipariş listesi yenilendi!');
            }, 1000);
        });
    }
    
    // View order details
    const viewButtons = document.querySelectorAll('.view-btn');
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const orderId = this.closest('tr').querySelector('td:first-child').textContent;
            alert(`Sipariş detayları için sipariş ID: ${orderId}\n\nGerçek bir uygulamada burada sipariş detayları modalı açılacaktı.`);
        });
    });
    
    // Cancel order
    const cancelButtons = document.querySelectorAll('.cancel-btn');
    cancelButtons.forEach(button => {
        button.addEventListener('click', function() {
            const orderId = this.closest('tr').querySelector('td:first-child').textContent;
            if (confirm(`${orderId} numaralı siparişi iptal etmek istediğinize emin misiniz?`)) {
                // In a real application, you would send a request to cancel the order
                alert('Sipariş iptal edildi!');
                // Update the status in the UI
                const statusCell = this.closest('tr').querySelector('.status-badge');
                statusCell.className = 'status-badge status-cancelled';
                statusCell.textContent = 'İptal Edildi';
                // Disable the cancel button
                this.disabled = true;
                this.title = 'İptal Edildi';
            }
        });
    });
    
    // Pagination
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    
    if (prevBtn) {
        prevBtn.addEventListener('click', function() {
            if (!this.disabled) {
                alert('Önceki sayfa yüklendi!');
            }
        });
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', function() {
            alert('Sonraki sayfa yüklendi!');
        });
    }
    
    // Filter orders function (mock)
    function filterOrders() {
        // In a real application, you would filter the orders based on the selected filters
        console.log('Orders filtered');
    }
    
    // Load user data
    function loadUserData() {
        // In a real application, you would fetch user data from API or localStorage
        const user = JSON.parse(localStorage.getItem('user')) || { username: 'admin', balance: '1,250.00' };
        if (document.getElementById('username')) {
            document.getElementById('username').textContent = user.username;
        }
        if (document.getElementById('balance')) {
            document.getElementById('balance').textContent = `₺${user.balance}`;
        }
    }
    
    // Initialize
    loadUserData();
});
