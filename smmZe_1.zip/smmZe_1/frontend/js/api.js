document.addEventListener('DOMContentLoaded', function() {
    // Theme toggle functionality
    const themeToggle = document.getElementById('themeToggle');
    const htmlElement = document.documentElement;
    
    // Check for saved theme or prefer-color-scheme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        htmlElement.setAttribute('data-theme', savedTheme);
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        htmlElement.setAttribute('data-theme', 'dark');
    }
    
    // Theme toggle button event
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            const currentTheme = htmlElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            htmlElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
        });
    }
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show confirmation
            if (confirm('Çıkış yapmak istediğinize emin misiniz?')) {
                // API logout call
                fetch('../../backend/api/auth.php?action=logout', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Clear user data from localStorage
                        localStorage.removeItem('user');
                        // Redirect to login page
                        window.location.href = 'login.html';
                    } else {
                        alert('Çıkış yapılırken bir hata oluştu.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    window.location.href = 'login.html'; // Fallback
                });
            }
        });
    }
    
    // Copy API key
    const copyKeyBtn = document.getElementById('copy-key');
    const apiKeyInput = document.getElementById('api-key');
    
    if (copyKeyBtn && apiKeyInput) {
        copyKeyBtn.addEventListener('click', function() {
            apiKeyInput.select();
            document.execCommand('copy');
            const originalText = this.innerHTML;
            this.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg> Kopyalandı!';
            setTimeout(() => {
                this.innerHTML = originalText;
            }, 2000);
        });
    }
    
    // Generate new API key
    const generateKeyBtn = document.getElementById('generate-key');
    if (generateKeyBtn) {
        generateKeyBtn.addEventListener('click', function() {
            if (confirm('Yeni bir API anahtarı oluşturmak istediğinize emin misiniz? Eski anahtarınız geçersiz hale gelecektir.')) {
                // In a real application, you would send a request to generate a new API key
                const newKey = 'sk_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
                if (apiKeyInput) {
                    apiKeyInput.value = newKey;
                }
                alert('Yeni API anahtarınız oluşturuldu!');
            }
        });
    }
    
    // Load user data
    function loadUserData() {
        // In a real application, you would fetch user data from API or localStorage
        const user = JSON.parse(localStorage.getItem('user')) || { username: 'admin', balance: '1,250.00' };
        if (document.getElementById('username')) {
            document.getElementById('username').textContent = user.username;
        }
        if (document.getElementById('balance')) {
            document.getElementById('balance').textContent = `₺${user.balance}`;
        }
    }
    
    // Initialize
    loadUserData();
});