document.addEventListener('DOMContentLoaded', function() {
    // Theme toggle functionality
    const themeToggle = document.getElementById('themeToggle');
    const htmlElement = document.documentElement;
    
    // Check for saved theme or prefer-color-scheme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        htmlElement.setAttribute('data-theme', savedTheme);
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        htmlElement.setAttribute('data-theme', 'dark');
    }
    
    // Theme toggle button event
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            const currentTheme = htmlElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            htmlElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
        });
    }
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show confirmation
            if (confirm('Çıkış yapmak istediğinize emin misiniz?')) {
                // API logout call
                fetch('../../backend/api/auth.php?action=logout', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Clear user data from localStorage
                        localStorage.removeItem('user');
                        // Redirect to login page
                        window.location.href = 'login.html';
                    } else {
                        alert('Çıkış yapılırken bir hata oluştu.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    window.location.href = 'login.html'; // Fallback
                });
            }
        });
    }
    
    // Profile form submission
    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const email = document.getElementById('email').value;
            const firstName = document.getElementById('firstName').value;
            const lastName = document.getElementById('lastName').value;
            const phone = document.getElementById('phone').value;
            
            // Validation
            if (!email || !firstName || !lastName) {
                alert('Lütfen gerekli alanları doldurun.');
                return;
            }
            
            // Show loading state
            const submitBtn = profileForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = 'Güncelleniyor...';
            submitBtn.disabled = true;
            
            // Simulate API call (in real implementation, you would send to your backend)
            setTimeout(() => {
                alert('Profil bilgileriniz başarıyla güncellendi!');
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 1500);
        });
    }
    
    // Password change modal
    const changePasswordBtn = document.getElementById('changePasswordBtn');
    const passwordModal = document.getElementById('passwordModal');
    const modalClose = passwordModal ? passwordModal.querySelector('.modal-close') : null;
    const passwordForm = document.getElementById('passwordForm');
    
    if (changePasswordBtn && passwordModal) {
        changePasswordBtn.addEventListener('click', function() {
            passwordModal.style.display = 'block';
        });
        
        if (modalClose) {
            modalClose.addEventListener('click', function() {
                passwordModal.style.display = 'none';
            });
        }
        
        window.addEventListener('click', function(e) {
            if (e.target === passwordModal) {
                passwordModal.style.display = 'none';
            }
        });
        
        if (passwordForm) {
            passwordForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Get form values
                const currentPassword = document.getElementById('currentPassword').value;
                const newPassword = document.getElementById('newPassword').value;
                const confirmPassword = document.getElementById('confirmPassword').value;
                
                // Validation
                if (!currentPassword || !newPassword || !confirmPassword) {
                    alert('Lütfen tüm alanları doldurun.');
                    return;
                }
                
                if (newPassword !== confirmPassword) {
                    alert('Yeni şifreler eşleşmiyor.');
                    return;
                }
                
                if (newPassword.length < 6) {
                    alert('Yeni şifre en az 6 karakter olmalıdır.');
                    return;
                }
                
                // Show loading state
                const submitBtn = passwordForm.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = 'Güncelleniyor...';
                submitBtn.disabled = true;
                
                // Simulate API call (in real implementation, you would send to your backend)
                setTimeout(() => {
                    alert('Şifreniz başarıyla değiştirildi!');
                    passwordForm.reset();
                    passwordModal.style.display = 'none';
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }, 1500);
            });
        }
    }
    
    // Toggle switches
    const toggleSwitches = document.querySelectorAll('.toggle-switch input');
    toggleSwitches.forEach(switchInput => {
        switchInput.addEventListener('change', function() {
            // In a real application, you would send this preference to your backend
            console.log(`${this.id} changed to ${this.checked}`);
        });
    });
    
    // Load user data
    function loadUserData() {
        // In a real application, you would fetch user data from API or localStorage
        const user = JSON.parse(localStorage.getItem('user')) || { 
            username: 'admin', 
            balance: '1,250.00',
            email: 'admin@smmpanel.com',
            firstName: 'Sistem',
            lastName: 'Yöneticisi'
        };
        
        if (document.getElementById('username')) {
            document.getElementById('username').textContent = user.username;
        }
        if (document.getElementById('balance')) {
            document.getElementById('balance').textContent = `₺${user.balance}`;
        }
        if (document.getElementById('email')) {
            document.getElementById('email').value = user.email;
        }
        if (document.getElementById('firstName')) {
            document.getElementById('firstName').value = user.firstName;
        }
        if (document.getElementById('lastName')) {
            document.getElementById('lastName').value = user.lastName;
        }
    }
    
    // Initialize
    loadUserData();
});