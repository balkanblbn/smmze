document.addEventListener('DOMContentLoaded', function() {
    // Theme toggle functionality
    const themeToggle = document.getElementById('themeToggle');
    const htmlElement = document.documentElement;
    
    // Check for saved theme or prefer-color-scheme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        htmlElement.setAttribute('data-theme', savedTheme);
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        htmlElement.setAttribute('data-theme', 'dark');
    }
    
    // Theme toggle button event
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            const currentTheme = htmlElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            htmlElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
        });
    }
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show confirmation
            if (confirm('Çıkış yapmak istediğinize emin misiniz?')) {
                // API logout call
                fetch('../../backend/api/auth.php?action=logout', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Clear user data from localStorage
                        localStorage.removeItem('user');
                        // Redirect to login page
                        window.location.href = 'login.html';
                    } else {
                        alert('Çıkış yapılırken bir hata oluştu.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    window.location.href = 'login.html'; // Fallback
                });
            }
        });
    }
    
    // Category filtering
    const categoryButtons = document.querySelectorAll('.category-btn');
    const serviceCards = document.querySelectorAll('.service-card');
    
    categoryButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Update active button
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Get selected category
            const category = this.getAttribute('data-category');
            
            // Filter services
            serviceCards.forEach(card => {
                if (category === 'all' || card.getAttribute('data-category') === category) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
    
    // Order buttons
    const orderButtons = document.querySelectorAll('.order-btn');
    orderButtons.forEach(button => {
        button.addEventListener('click', function() {
            const serviceName = this.closest('.service-card').querySelector('h3').textContent;
            alert(`${serviceName} için yeni sipariş oluşturulacak. Gerçek bir uygulamada burada yeni sipariş sayfasına yönlendirme yapılacaktı.`);
        });
    });
    
    // Load user data
    function loadUserData() {
        // In a real application, you would fetch user data from API or localStorage
        const user = JSON.parse(localStorage.getItem('user')) || { username: 'admin', balance: '1,250.00' };
        if (document.getElementById('username')) {
            document.getElementById('username').textContent = user.username;
        }
        if (document.getElementById('balance')) {
            document.getElementById('balance').textContent = `₺${user.balance}`;
        }
    }
    
    // Initialize
    loadUserData();
});