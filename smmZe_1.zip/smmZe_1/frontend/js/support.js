document.addEventListener('DOMContentLoaded', function() {
    // Theme toggle functionality
    const themeToggle = document.getElementById('themeToggle');
    const htmlElement = document.documentElement;
    
    // Check for saved theme or prefer-color-scheme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        htmlElement.setAttribute('data-theme', savedTheme);
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        htmlElement.setAttribute('data-theme', 'dark');
    }
    
    // Theme toggle button event
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            const currentTheme = htmlElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            htmlElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
        });
    }
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show confirmation
            if (confirm('Çıkış yapmak istediğinize emin misiniz?')) {
                // API logout call
                fetch('../../backend/api/auth.php?action=logout', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Clear user data from localStorage
                        localStorage.removeItem('user');
                        // Redirect to login page
                        window.location.href = 'login.html';
                    } else {
                        alert('Çıkış yapılırken bir hata oluştu.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    window.location.href = 'login.html'; // Fallback
                });
            }
        });
    }
    
    // Support form submission
    const supportForm = document.getElementById('supportForm');
    if (supportForm) {
        supportForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const subject = document.getElementById('support-subject').value;
            const priority = document.getElementById('support-priority').value;
            const category = document.getElementById('support-category').value;
            const message = document.getElementById('support-message').value;
            
            // Validation
            if (!subject || !priority || !category || !message) {
                alert('Lütfen tüm alanları doldurun.');
                return;
            }
            
            // Show loading state
            const submitBtn = supportForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = 'Gönderiliyor...';
            submitBtn.disabled = true;
            
            // Simulate API call (in real implementation, you would send to your backend)
            setTimeout(() => {
                alert('Destek talebiniz başarıyla oluşturuldu! En kısa sürede yanıtlanacaktır.');
                supportForm.reset();
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 1500);
        });
    }
    
    // Load user data
    function loadUserData() {
        // In a real application, you would fetch user data from API or localStorage
        // localStorage'da hassas veri tutma, sadece gerekli minimum bilgiyi al
        let user = { username: 'admin', balance: '1,250.00' };
        try {
            const stored = localStorage.getItem('user');
            if (stored) {
                const parsed = JSON.parse(stored);
                if (parsed && typeof parsed.username === 'string' && typeof parsed.balance !== 'undefined') {
                    user = { username: parsed.username, balance: parsed.balance };
                }
            }
        } catch (e) {}
        if (document.getElementById('username')) {
            document.getElementById('username').textContent = user.username;
        }
        if (document.getElementById('balance')) {
            document.getElementById('balance').textContent = `₺${user.balance}`;
        }
    }
    
    // Initialize
    loadUserData();
});